<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: /");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Upload</title>
    <link rel="stylesheet" href="/assets/style.css">
    <script src="/assets/sweetalert.js"></script>
</head>
<body>
    <div class="container">
        <h2>Upload File</h2>
        <form id="upload-form">
            <input type="file" id="file" name="file" required>
            <button type="submit">Upload</button>
        </form>
        <a href="/files">My files</a>
    </div>

<script>
document.getElementById("upload-form").addEventListener("submit", function(e) {
    e.preventDefault();
    
    const fileInput = document.getElementById("file");
    const file = fileInput.files[0];

    if (!file) {
        Swal.fire({
            icon: 'warning',
            title: 'No file selected',
            text: 'Please select a file to upload.'
        });
        return;
    }

    const formData = new FormData();
    formData.append("method", "upload");
    formData.append("file", file);

    fetch('/api/actions', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.ok) {
            Swal.fire({
                icon: 'success',
                title: 'Upload Successful',
                text: data.ok
            });
            fileInput.value = "";
        } else if (data.error) {
            Swal.fire({
                icon: 'error',
                title: 'Upload Failed',
                text: data.error
            });
        }
    })
    .catch(err => {
        Swal.fire({
            icon: 'error',
            title: 'Unexpected Error',
            text: 'Something went wrong while uploading the file.'
        });
    });
});
</script>
</body>
</html>
