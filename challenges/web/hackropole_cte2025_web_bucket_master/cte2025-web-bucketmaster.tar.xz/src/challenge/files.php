<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: /");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Files</title>
    <link rel="stylesheet" href="/assets/style.css">
    <script src="/assets/sweetalert.js"></script>
    <style>
        .file-list { margin-top: 30px; }
        .file-list li {
            background: #f9f9f9;
            padding: 10px;
            margin: 10px 0;
            border-radius: 6px;
            display: flex;
            justify-content: space-between;
        }
        .file-list a {
            color: #007bff;
            text-decoration: none;
        }
        .file-list a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Your Files</h2>
    <ul class="file-list" id="file-list"></ul>
    <a href="/upload">Upload files</a>
</div>

<script>
fetch('/api/actions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'method=list_files'
})
.then(res => res.json())
.then(data => {
    if (data.files) {
        const list = document.getElementById('file-list');
        list.innerHTML = '';
        if(data.files.length == 0) {
            Swal.fire({ icon: 'error', title: 'Error', text: "You don't have any files." }).then(() => {
                window.location.href = "/upload";
            });
            return;
        }
        data.files.forEach(file => {
            const li = document.createElement('li');
            const link = document.createElement('a');
            link.href = '#';
            link.textContent = 'Download';
            link.onclick = (e) => {
                e.preventDefault();
                const formData = new URLSearchParams();
                formData.append("method", "download_file");
                formData.append("id", file.id);

                fetch('/api/actions', {
                    method: 'POST',
                    body: formData
                })
                .then(resp => {
                    if (resp.ok) {
                        return resp.blob();
                    } else {
                        return resp.json().then(err => {
                            throw new Error(err.error || "Failed");
                        });
                    }
                })
                .then(blob => {
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = file.name;
                    a.click();
                    window.URL.revokeObjectURL(url);
                })
                .catch(err => {
                    Swal.fire({ icon: "error", title: "Download failed", text: err.message });
                });
            };
            li.textContent = file.name + ' ';
            li.appendChild(link);
            list.appendChild(li);
        });
    } else {
        Swal.fire({ icon: 'error', title: 'Error', text: data.error || "Couldn't fetch files." });
    }
});

</script>
</body>
</html>
