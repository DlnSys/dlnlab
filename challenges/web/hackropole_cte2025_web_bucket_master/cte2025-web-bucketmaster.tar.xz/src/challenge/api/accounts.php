<?php

if($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: /");
    die();
}

session_start();
header("Content-Type: application/json");

$method = $_POST['method'] ?? '';
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

require_once('config.php');

$db = get_db();

if ($method === 'register') {
    if (strlen($username) < 4 || strlen($username) > 8) {
        http_response_code(422);
        die(json_encode(["error" => "Username must be 4-8 characters."]));
    }
    if (strlen($password) < 8) {
        http_response_code(422);
        die(json_encode(["error" => "Password must be at least 8 characters."]));
    }

    if(strpos($username, "/") || strpos($username, ".")) {
        http_response_code(422);
        die(json_encode(["error" => "The username is not correct."]));
    }

    $stmt = $db->prepare("SELECT username FROM users WHERE username = :username");
    $stmt->bindValue(':username', $username, SQLITE3_TEXT);
    $res = $stmt->execute();
    if ($res->fetchArray()) {
        http_response_code(422);
        die(json_encode(["error" => "Username already taken."]));
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $db->prepare("INSERT INTO users (username, password) VALUES (:username, :password)");
    $stmt->bindValue(':username', $username, SQLITE3_TEXT);
    $stmt->bindValue(':password', $hashedPassword, SQLITE3_TEXT);
    $stmt->execute();

    $_SESSION['username'] = $username;
    die(json_encode(["ok" => "Account created."]));
}

if ($method === 'login') {
    $stmt = $db->prepare("SELECT password FROM users WHERE username = :username");
    $stmt->bindValue(':username', $username, SQLITE3_TEXT);
    $res = $stmt->execute();
    $row = $res->fetchArray();
    if (!$row || !password_verify($password, $row['password'])) {
        http_response_code(401);
        die(json_encode(["error" => "Invalid credentials."]));
    }

    $_SESSION['username'] = $username;
    die(json_encode(["error" => "User connected."]));
}
?>