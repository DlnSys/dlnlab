<?php

if($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: /");
    die();
}

session_start();
header("Content-Type: application/json");

if (!isset($_SESSION['username'])) {
    http_response_code(401);
    die(json_encode(["error" => "Please authenticate."]));
}

require_once('config.php');

$method = $_POST['method'] ?? '';
$db = get_db();

if ($method === "upload") {
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        http_response_code(422);
        die(json_encode(["error" => "No file specified or file too large."]));
    }

    if ($_FILES['file']['size'] > 1024 * 1024) {
        http_response_code(413);
        die(json_encode(["error" => "Entity too large (max 1Mo)."]));
    }

    $rand = bin2hex(random_bytes(32));
    $extension = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
    $filename = uniqid($_SESSION["username"]."_".$rand).".".$extension;
    $targetFile = $uploadDir . $filename;

    if (move_uploaded_file($_FILES['file']['tmp_name'], $targetFile)) {
        die(json_encode(["ok" => "File uploaded successfully."]));
    } else {
        http_response_code(500);
        die(json_encode(["error" => "Upload failed."]));
    }
}

if ($method === "list_files") {
    $user = $_SESSION['username'];
    $uploadDir = "/var/www/html/uploads/";
    $files = [];

    foreach (scandir($uploadDir) as $file) {
        if ($file === '.' || $file === '..') continue;

        $underscorePos = strpos($file, "_");
        if ($underscorePos === false) continue;

        $prefix = substr($file, 0, $underscorePos);
        $rest = substr($file, $underscorePos + 1);

        if ($prefix !== $user) continue;

        $dotPos = strrpos($rest, ".");
        if ($dotPos === false) continue;

        $namePart = substr($rest, 0, $dotPos);
        $extension = substr($rest, $dotPos + 1);

        $endfilename = substr($namePart, -5);

        $displayName = $user . "_..." . $endfilename . '.' . $extension;

        $files[] = [
            "id" => count($files) + 1,
            "name" => $displayName
        ];
    }

    echo json_encode(["files" => $files]);
    exit;
}

if ($method === "download_file") {
    $user = $_SESSION['username'];
    $id = intval($_POST['id'] ?? 0);
    $uploadDir = "/var/www/html/uploads/";
    $files = [];

    foreach (scandir($uploadDir) as $file) {
        if (strpos($file, $user . "_") === 0) {
            $files[] = $file;
        }
    }

    if ($id < 1 || $id > count($files)) {
        http_response_code(404);
        die(json_encode(["error" => "Invalid file ID."]));
    }

    $target = $uploadDir . $files[$id - 1];
    if (!file_exists($target)) {
        http_response_code(404);
        die(json_encode(["error" => "File not found."]));
    }
    $extension = pathinfo($target, PATHINFO_EXTENSION);

    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $user . "_" . $id . "." . $extension . '"');
    readfile($target);
    exit;
}
?>