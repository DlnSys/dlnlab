<?php

$uploadDir = "/var/www/html/uploads/";

set_error_handler(function ($severity, $message, $file, $line) {
    http_response_code(500);
    die("An error occured.");
});

function get_db() {
    $db_path = '/tmp/app.db';
    return new SQLite3($db_path);
}