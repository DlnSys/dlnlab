<?php
session_start();
if (isset($_SESSION['username'])) {
    header("Location: /upload");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Main Page</title>
    <link rel="stylesheet" href="/assets/style.css">
    <script src="/assets/sweetalert.js"></script>
</head>
<body>
    <div class="container">
        <h1>Welcome</h1>
        <div class="buttons">
            <button onclick="openModal('login')">Login</button>
            <button onclick="openModal('register')">Register</button>
        </div>
    </div>

    <div class="modal" id="modal-login">
        <div class="modal-content">
            <span class="close" onclick="closeModal('login')">&times;</span>
            <h2>Login</h2>
            <input type="text" id="login-username" placeholder="Username">
            <input type="password" id="login-password" placeholder="Password">
            <button onclick="submitLogin()">Submit</button>
        </div>
    </div>

    <div class="modal" id="modal-register">
        <div class="modal-content">
            <span class="close" onclick="closeModal('register')">&times;</span>
            <h2>Register</h2>
            <input type="text" id="register-username" placeholder="Username (4-8 chars)">
            <input type="password" id="register-password" placeholder="Password (min 8 chars)">
            <button onclick="submitRegister()">Submit</button>
        </div>
    </div>

<script>
function openModal(type) {
    document.getElementById('modal-' + type).style.display = 'block';
}
function closeModal(type) {
    document.getElementById('modal-' + type).style.display = 'none';
}

function submitLogin() {
    const username = document.getElementById("login-username").value;
    const password = document.getElementById("login-password").value;

    fetch('/api/accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'method=login&username=' + encodeURIComponent(username) + '&password=' + encodeURIComponent(password)
    })
    .then(res => res.json())
    .then(data => {
        if (data.error === "User connected.") {
            window.location.href = "/upload";
        } else {
            Swal.fire({
                icon: "error",
                title: "Login failed",
                text: data.error || "Unknown error"
            });
        }
    });
}

function submitRegister() {
    const username = document.getElementById("register-username").value;
    const password = document.getElementById("register-password").value;

    fetch('/api/accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'method=register&username=' + encodeURIComponent(username) + '&password=' + encodeURIComponent(password)
    })
    .then(res => res.json())
    .then(data => {
        if (data.ok) {
            Swal.fire({
                icon: "success",
                title: "Account created",
                text: data.ok
            }).then(() => {
                window.location.href = "/upload";
            });
        } else if (data.error) {
            Swal.fire({
                icon: "error",
                title: "Registration failed",
                text: data.error
            });
        }
    });
}
</script>
</body>
</html>
