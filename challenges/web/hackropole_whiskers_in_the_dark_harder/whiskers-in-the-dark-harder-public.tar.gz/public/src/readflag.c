#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{
  if (argc != 2 || strcmp(argv[1], "GIMMETHEFLAG") != 0)
  {
    printf("Usage: %s GIMMETHEFLAG\n", argv[0]);
    exit(0);
  }

  char buf[0x100];
  FILE *fp = fopen("/flag.txt", "r");
  if (fp == NULL)
  {
    printf("No flag file found\n");
    exit(0);
  }

  fgets(buf, 0x100, fp);
  printf("%s", buf);
  return 0;
}