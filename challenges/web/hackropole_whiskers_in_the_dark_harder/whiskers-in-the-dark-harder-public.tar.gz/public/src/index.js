import express from "express";
import { execFile } from "child_process";

const app = express();

app.set("trust proxy", true);

app.use(express.static("public"));

app.get("/fortune", (req, res) => {
  const args = ["--color", "never"].concat(req.query.f);

  if (args.some((arg) => arg.match(/[^a-z0-9./_=\-]/i))) {
    return res.status(400).send({ error: "Invalid filename." });
  }

  execFile("bat", args, { cwd: "./fortunes" }, (error, stdout, stderr) => {
    if (error) {
      res.status(500).send({ error: stderr });
    } else {
      res.send({ fortune: stdout });
    }
  });
});

app.listen(8000, () => {
  console.log("App listening on port 8000!");
});
