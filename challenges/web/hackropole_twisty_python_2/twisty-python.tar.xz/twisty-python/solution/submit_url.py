from urllib.parse import quote
from requests import session
from hashlib import sha512
from os import urandom
import argparse

def get_challenge(s, DOMAIN):
    return s.get(f"{DOMAIN}/visit").json()

def solve_challenge(chall):
    solved = False
    while not solved:
        solve = urandom(24).hex()
        pow = sha512(solve.encode()).hexdigest()[:len(chall)]
        if pow == chall:
            solved = True
    return solve

def send_bot(s, DOMAIN, URL, pow):
    s.get(f"{DOMAIN}/visit?url={quote(URL)}&pow={pow}")

def get_args():
    parser = argparse.ArgumentParser(description="")

    parser.add_argument("--challenge", required = True, help = "DOMAIN of the challenge instance (e.g., http://127.0.0.1:8000)")
    parser.add_argument("--url", required = True, help = "URL to send the bot to (ie: http://domain.com/path).")

    return parser.parse_args()

if __name__ == "__main__":
    args = get_args()
    s = session()
    # Handle PoW
    try:
        chall = get_challenge(s, args.challenge)["chall"]
        pow = solve_challenge(chall)
    except:
        pow = ""
    send_bot(s, args.challenge, args.url, pow)
    print("Done.")
