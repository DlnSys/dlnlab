// Don't waste your time auditing this main.js file, it's not part of the challenge.

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const scoreElement = document.getElementById('score');
const submitScoreBtn = document.getElementById('submitScoreBtn');
const box = 20;
const canvasSize = 20;
let snake = [];
let score = 0;
let d;
let game;
let leaderboardData = [];

function parseCookie(cookiesString) {
    return cookiesString.split(";")
      .map(function(cookieString) {
          return cookieString.trim().split("=");
      })
      .reduce(function(acc, curr) {
          acc[curr[0]] = curr[1];
          return acc;
      }, {});
}
  
var color = parseCookie(document.cookie)["color"];

function initGame() {
    updateColor();
    fetch("/api?action=view").then(d => d.json()).then((d) => {
        leaderboardData = d;
        updateLeaderboard();
    });
    snake = [{ x: 10 * box, y: 10 * box }];
    score = 0;
    updateScore();
    d = null;
    game = setInterval(draw, 100);
    submitScoreBtn.disabled = true;
}

function createFood() {
    return {
        x: Math.floor(Math.random() * canvasSize) * box,
        y: Math.floor(Math.random() * canvasSize) * box
    };
}

let food = createFood();

document.addEventListener('keydown', direction);

function direction(event) {
    if (event.keyCode === 37 && d !== 'RIGHT') {
        d = 'LEFT';
    } else if (event.keyCode === 38 && d !== 'DOWN') {
        d = 'UP';
    } else if (event.keyCode === 39 && d !== 'LEFT') {
        d = 'RIGHT';
    } else if (event.keyCode === 40 && d !== 'UP') {
        d = 'DOWN';
    }
}

function collision(head, array) {
    return array.some(segment => head.x === segment.x && head.y === segment.y);
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (let i = 0; i < snake.length; i++) {
        ctx.fillStyle = (i === 0) ? 'darkgreen' : 'green';
        ctx.fillRect(snake[i].x, snake[i].y, box, box);
    }

    ctx.fillStyle = 'red';
    ctx.fillRect(food.x, food.y, box, box);

    let snakeX = snake[0].x;
    let snakeY = snake[0].y;

    if (d === 'LEFT') snakeX -= box;
    if (d === 'UP') snakeY -= box;
    if (d === 'RIGHT') snakeX += box;
    if (d === 'DOWN') snakeY += box;

    if (snakeX === food.x && snakeY === food.y) {
        score++;
        updateScore();
        food = createFood();
    } else {
        snake.pop();
    }

    let newHead = { x: snakeX, y: snakeY };

    if (snakeX < 0 || snakeY < 0 || snakeX >= canvas.width || snakeY >= canvas.height || collision(newHead, snake)) {
        clearInterval(game);
        gameOver();
        return;
    }

    snake.unshift(newHead);
}

function gameOver() {
    ctx.font = "30px Arial";
    ctx.fillStyle = "black";
    ctx.fillText("GAME OVER", 100, canvas.height / 2);
    submitScoreBtn.disabled = false;
}

function setColor(color) {
    fetch(`/api?action=color&color=${color}&callback={"status": "OK"}`).then(() => {
        updateColor();
    });
}

function updateColor() {
    document.body.classList.remove(`bg-${color}-200`);
    document.getElementById("submitScoreBtn").classList.remove(`bg-${color}-200`);
    document.getElementById("playerName").classList.remove(`bg-${color}-200`);
    document.getElementById("restartBtn").classList.remove(`bg-${color}-200`);

    color = parseCookie(document.cookie)["color"];
    color = color ? color : "yellow";

    document.body.classList.add(`bg-${color}-200`);
    document.getElementById("submitScoreBtn").classList.add(`bg-${color}-200`);
    document.getElementById("playerName").classList.add(`bg-${color}-200`);
    document.getElementById("restartBtn").classList.add(`bg-${color}-200`);
}

function updateScore() {
    scoreElement.innerText = `Score: ${score}`;
}

function submitScore() {
    const playerName = document.getElementById('playerName').value || 'Unknown';
    fetch("/api?action=add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: playerName, score: score })
    })
    leaderboardData.push({ name: playerName, score: score });
    updateLeaderboard();
}

function updateLeaderboard() {
    leaderboardData.sort((a, b) => b.score - a.score);
    const leaderboardElement = document.getElementById('leaderboard');
    leaderboardElement.innerHTML = '';
    leaderboardData.forEach(entry => {
        const li = document.createElement('li');
        li.textContent = `${entry.name}: ${entry.score}`;
        leaderboardElement.appendChild(li);
    });
}

function restartGame() {
    initGame();
}

initGame();
