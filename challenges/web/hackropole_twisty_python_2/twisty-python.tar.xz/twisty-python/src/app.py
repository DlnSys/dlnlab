from flask import Flask, session, request, Response, render_template, jsonify
from os import urandom, environ
from hashlib import sha512
import bot

# Init
app = Flask(__name__)
app.secret_key = urandom(24)

# Utils
def init(session):
    if "scores" not in session:
        session["scores"] = []

# Routes
@app.route("/")
def index():
    init(session)
    return render_template("index.html")

@app.route("/api", methods=["GET", "POST"])
def note():
    init(session)
    action = request.args.get("action")
    if not action:
        return jsonify({"error": "?action= must be set!"})

    if action == "color":
        res = Response(request.args.get("callback"))
        res.headers["Content-Type"] = "text/plain"
        res.headers["Set-Cookie"] = f"color={request.args.get('color', 'red')}"
        return res

    if action == "add":
        if not request.method == "POST":
            return jsonify({"error": "invalid HTTP method"})

        d = request.form if request.form else request.get_json()
        if not ("name" in d and "score" in d):
            return jsonify({"error": "name and score must be set"})

        session["scores"] += [{"name": d["name"], "score": d["score"]}]
        return jsonify({"length": len(session["scores"])})

    if action == "view":
        raw = request.args.get("raw", False)

        if raw:
            res = Response("".join([ f"{v['name']} -> {v['score']}\n" for v in session["scores"] ]))
            res.headers["Content-Type"] = "text/plain"
        else:
            res = jsonify(session["scores"])

        return res

    if action == "clear":
        session.clear()
        return jsonify({"clear": True})

    return jsonify({"error": "invalid action value (color || add || view || clear)"})

# This part of the code is only used for the bot to visit the exploitation link.
# Don't lose your time auditing it.
def verify_pow(session, pow, difficulty=6):
    pow = sha512(pow.encode()).hexdigest()[:difficulty]
    ret = "chall" in session and session["chall"] == pow
    session["chall"] = sha512(urandom(24).hex().encode()).hexdigest()[:difficulty]
    return ret

@app.route("/visit")
def visit():
    if not environ.get("LOCAL") and not verify_pow(session, request.args.get("pow", "random")):
        return jsonify({"chall": session["chall"]})

    url = request.args.get("url")
    if url and (url.startswith("https://") or url.startswith("http://")):
        bot.visit(url)
        return jsonify({"Visit": "OK"})
    else:
        return jsonify({"Error": "?url= must be set and starts with https:// or http://"})

if __name__ == "__main__":
    app.run("0.0.0.0", 8000)
